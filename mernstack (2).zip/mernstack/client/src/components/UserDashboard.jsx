// UserDashboard.js

import React from 'react';
import '../UserDashboard.css';

const UserDashboard = () => {
    return (
        <div className="user-dashboard">
            <h2>User Dashboard</h2>
            {/* Add dashboard content */}
            <p>Welcome to your user dashboard!</p>
            <ul>
                <li>View Profile</li>
                <li>Book Appointment</li>
                <li>View Appointments</li>
                {/* Add more dashboard features */}
            </ul>
        </div>
    );
}

export default UserDashboard;
