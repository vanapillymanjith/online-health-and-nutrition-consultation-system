// AppointmentBooking.js

import React from 'react';
import '../AppointmentBooking.css';

const AppointmentBooking = () => {
    return (
        <div className="appointment-booking">
            <h2>Appointment Booking</h2>
            <form className="booking-form">
                {/* Add booking form fields */}
                <div className="form-group">
                    <label htmlFor="name">Name:</label>
                    <input type="text" id="name" name="name" />
                </div>
                <div className="form-group">
                    <label htmlFor="email">Email:</label>
                    <input type="email" id="email" name="email" />
                </div>
                <div className="form-group">
                    <label htmlFor="date">Date:</label>
                    <input type="date" id="date" name="date" />
                </div>
                <div className="form-group">
                    <label htmlFor="time">Time:</label>
                    <input type="time" id="time" name="time" />
                </div>
                <button type="submit">Book Appointment</button>
            </form>
        </div>
    );
}

export default AppointmentBooking;
