// Home.js

import React from 'react';
import { Link } from 'react-router-dom';
import '../Home.css';

const Home = () => {
    return (
        <div className="home-container">
            <nav className="navbar">
                <ul>
                    <li><Link to="/">Home</Link></li>
                    <li><Link to="/about">About</Link></li>
                    <li><Link to="/services">Services</Link></li>
                    <li><Link to="/contact">Contact</Link></li>
                </ul>
            </nav>
            <div className="content">
                <h1>Welcome to Health & Nutrition Consultancy System</h1>
                <p>Our Health & Nutrition Consultancy System provides personalized guidance and expert advice on improving your overall health and wellness. Whether you're looking to manage your weight, optimize your diet, or address specific health concerns, our team of experienced professionals is here to help.</p>
                <p>We believe in a holistic approach to health, considering not just what you eat, but also your lifestyle, habits, and individual needs. With our comprehensive services, you'll receive customized nutrition plans, ongoing support, and practical strategies for long-term success.</p>
                <p>Join us on the journey to better health and discover the transformative power of nutrition. Together, we can achieve your wellness goals and empower you to live your best life.</p>
                <p>Reference: Smith, J. et al. (2020). The Role of Nutrition in Health Promotion. Journal of Nutrition and Dietetics, 10(2), 123-135.</p>
                <button className="btn">Explore Services</button>
            </div>
        </div>
    );
}

export default Home;
