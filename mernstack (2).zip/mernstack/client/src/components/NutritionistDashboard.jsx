// NutritionistDashboard.js

import React from 'react';
import '../NutritionistDashboard.css';
import { useNavigate } from 'react-router-dom';

const NutritionistDashboard = () => {
    const navigator=useNavigate();
    return (
        <div className="nutritionist-dashboard">
            <h2>Nutritionist Dashboard</h2>
            <div className="dashboard-content">
                <div className="stats">
                    <h3>Statistics</h3>
                    {/* Placeholder for statistics */}
                </div>
                <div className="appointments">
                    <h3>Appointments</h3>
                    navigate("/user/booking")
                </div>
                <div className="calendar">
                    <h3>Calendar</h3>
                    {/* Placeholder for calendar */}
                </div>
            </div>
        </div>
    );
}

export default NutritionistDashboard;
