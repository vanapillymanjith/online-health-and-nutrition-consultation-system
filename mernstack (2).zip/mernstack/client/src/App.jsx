import React from 'react';
import { BrowserRouter,Routes,Route} from 'react-router-dom';
import Home from './components/Home';
import UserLogin from './components/UserLogin';
import UserRegister from './components/UserRegister';
import NutritionistDashboard from './components/NutritionistDashboard';
import UserDashboard from './components/UserDashboard';
import AppointmentBooking from './components/AppointmentBooking';

function App() {
    return (
      <>
        <BrowserRouter>
            <Routes>
                  <Route exact path="/" element={<Home/>} />
                  <Route path="/login" element={<UserLogin/>} />
                  <Route path="/register" element={<UserRegister/>} />
                  <Route path="/nutritionist/dashboard" element={<NutritionistDashboard/>} />
                  <Route path="/user/dashboard" element={<UserDashboard/>} />
                  <Route path="/user/booking" element={<AppointmentBooking/>} />
            </Routes>
          </BrowserRouter>
      </>
    );
}

export default App;
