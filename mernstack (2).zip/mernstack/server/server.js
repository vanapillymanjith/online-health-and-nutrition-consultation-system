const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json()); // Parse JSON bodies

// Routes
app.get('/', (req, res) => {
    res.send('Welcome to the backend server!');
});

// Start server
app.listen(3000, () => {
    console.log(`Server is running on port ${3000}`);
});
